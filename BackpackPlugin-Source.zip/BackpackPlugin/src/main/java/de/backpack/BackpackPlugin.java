package de.backpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public final class BackpackPlugin extends JavaPlugin {

    private Backpacks backpacks;
    private final List<NamespacedKey> recipeKeys = new ArrayList<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        backpacks = new Backpacks(this);
        registerRecipes();
        getServer().getPluginManager().registerEvents(new BackpackListener(this, backpacks, recipeKeys), this);
    }

    @Override
    public void onDisable() {
        // Offene Rucksaecke schliessen, damit der Inhalt gespeichert wird
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof BackpackListener.BackpackHolder) {
                p.closeInventory();
            }
        }
    }

    private void registerRecipes() {
        NamespacedKey k1 = new NamespacedKey(this, "tier1");
        ShapedRecipe base = new ShapedRecipe(k1, backpacks.create(1, null));
        base.shape("LSL", "LCL", "LLL");
        base.setIngredient('L', Material.LEATHER);
        base.setIngredient('S', Material.STRING);
        base.setIngredient('C', Material.CHEST);
        Bukkit.addRecipe(base);
        recipeKeys.add(k1);

        Material[] mats = {null, null, Material.COPPER_INGOT, Material.IRON_INGOT, Material.GOLD_INGOT, Material.DIAMOND};
        for (int t = 2; t <= Backpacks.MAX_TIER; t++) {
            NamespacedKey k = new NamespacedKey(this, "upgrade_" + t);
            ShapedRecipe r = new ShapedRecipe(k, backpacks.create(t, null));
            r.shape("MMM", "MBM", "MMM");
            r.setIngredient('M', mats[t]);
            r.setIngredient('B', Material.LEATHER_HORSE_ARMOR);
            Bukkit.addRecipe(r);
            recipeKeys.add(k);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("backpack.admin")) {
                sender.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED));
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(Component.text("/backpack give <spieler> [stufe 1-5]", NamedTextColor.RED));
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(Component.text("Spieler nicht online.", NamedTextColor.RED));
                return true;
            }
            int tier = 1;
            if (args.length >= 3) {
                try {
                    tier = Math.max(1, Math.min(Backpacks.MAX_TIER, Integer.parseInt(args[2])));
                } catch (NumberFormatException ex) {
                    sender.sendMessage(Component.text("Stufe muss eine Zahl sein.", NamedTextColor.RED));
                    return true;
                }
            }
            ItemStack item = backpacks.create(tier, null);
            target.getInventory().addItem(item).values()
                    .forEach(rest -> target.getWorld().dropItemNaturally(target.getLocation(), rest));
            sender.sendMessage(Component.text("Rucksack Stufe " + tier + " an " + target.getName() + " gegeben.",
                    NamedTextColor.GREEN));
            return true;
        }

        sender.sendMessage(Component.text("Rucksack-Stufen:", NamedTextColor.GOLD));
        sender.sendMessage(Component.text("1 Leder: " + backpacks.slots(1) + " Slots - 7 Leder, 1 Faden, 1 Kiste",
                NamedTextColor.YELLOW));
        String[] mat = {"", "", "Kupferbarren", "Eisenbarren", "Goldbarren", "Diamanten"};
        for (int t = 2; t <= Backpacks.MAX_TIER; t++) {
            sender.sendMessage(Component.text(t + " " + Backpacks.NAMES[t - 1] + ": " + backpacks.slots(t)
                    + " Slots - Rucksack Stufe " + (t - 1) + " in die Mitte, 8x " + mat[t] + " drumherum",
                    NamedTextColor.YELLOW));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("backpack.admin")) return out;
        if (args.length == 1) out.add("give");
        if (args.length == 2) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        if (args.length == 3) {
            for (int i = 1; i <= Backpacks.MAX_TIER; i++) out.add(String.valueOf(i));
        }
        String last = args[args.length - 1].toLowerCase();
        out.removeIf(s -> !s.toLowerCase().startsWith(last));
        return out;
    }
}
