package de.backpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;

import java.util.List;
import java.util.UUID;

public final class BackpackListener implements Listener {

    public static final class BackpackHolder implements InventoryHolder {
        final UUID id;
        final int tier;
        Inventory inv;

        BackpackHolder(UUID id, int tier) {
            this.id = id;
            this.tier = tier;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final BackpackPlugin plugin;
    private final Backpacks bp;
    private final List<NamespacedKey> recipeKeys;

    public BackpackListener(BackpackPlugin plugin, Backpacks bp, List<NamespacedKey> recipeKeys) {
        this.plugin = plugin;
        this.bp = bp;
        this.recipeKeys = recipeKeys;
    }

    // ------------------------------------------------------------------ Oeffnen

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (!bp.isBackpack(item)) return;
        Player p = e.getPlayer();
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && !p.isSneaking()
                && e.getClickedBlock() != null && e.getClickedBlock().getType().isInteractable()) {
            return; // Kisten, Tueren usw. normal benutzen
        }
        e.setCancelled(true);
        open(p);
    }

    /** Verhindert, dass der Rucksack einem Pferd angelegt wird. */
    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (bp.isBackpack(e.getPlayer().getInventory().getItemInMainHand())
                || bp.isBackpack(e.getPlayer().getInventory().getItemInOffHand())) {
            e.setCancelled(true);
        }
    }

    private void open(Player p) {
        ItemStack hand = p.getInventory().getItemInMainHand().clone();
        int tier = bp.tier(hand);
        if (tier < 1) return;
        int slots = bp.slots(tier);
        ItemStack[] contents = bp.read(hand, slots);
        UUID id = bp.id(hand);
        if (id == null) { // erste Benutzung: eindeutige ID vergeben
            id = UUID.randomUUID();
            bp.write(hand, tier, id, contents);
            p.getInventory().setItemInMainHand(hand);
        }
        BackpackHolder h = new BackpackHolder(id, tier);
        h.inv = Bukkit.createInventory(h, slots,
                Component.text("Rucksack (" + Backpacks.NAMES[tier - 1] + ")"));
        h.inv.setContents(contents);
        p.openInventory(h.inv);
        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 1f, 1f);
    }

    // ------------------------------------------------------------------ Speichern

    /** Schreibt den Inhalt zurueck in das Rucksack-Item im Spielerinventar. */
    private boolean save(Player p, BackpackHolder h) {
        PlayerInventory pi = p.getInventory();
        ItemStack[] arr = h.inv.getContents();
        for (int i = 0; i < 41; i++) {
            ItemStack it = pi.getItem(i);
            if (it != null && h.id.equals(bp.id(it))) {
                ItemStack n = it.clone();
                bp.write(n, h.tier, h.id, arr);
                pi.setItem(i, n);
                return true;
            }
        }
        return false;
    }

    private BackpackHolder holderOf(Inventory inv) {
        return inv.getHolder() instanceof BackpackHolder h ? h : null;
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        BackpackHolder h = holderOf(e.getInventory());
        if (h == null || !(e.getPlayer() instanceof Player p)) return;
        if (!save(p, h) && !p.isDead()) {
            // Rucksack-Item nicht mehr auffindbar -> Inhalt droppen statt zu verlieren
            for (ItemStack i : h.inv.getContents()) {
                if (i != null && !i.getType().isAir()) p.getWorld().dropItemNaturally(p.getLocation(), i);
            }
            h.inv.clear();
        }
        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 1f, 0.8f);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        BackpackHolder h = holderOf(p.getOpenInventory().getTopInventory());
        if (h != null) save(p, h);
    }

    // ------------------------------------------------------------------ Schutz beim Bearbeiten

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        BackpackHolder h = holderOf(top);
        if (h == null || !(e.getWhoClicked() instanceof Player p)) return;

        ItemStack cur = e.getCurrentItem();
        ItemStack cursor = e.getCursor();
        ItemStack hot = null;
        if (e.getClick() == ClickType.NUMBER_KEY) {
            hot = p.getInventory().getItem(e.getHotbarButton());
        } else if (e.getClick() == ClickType.SWAP_OFFHAND) {
            hot = p.getInventory().getItemInOffHand();
        }

        // der geoeffnete Rucksack selbst darf nicht bewegt werden
        if (h.id.equals(bp.id(cur)) || h.id.equals(bp.id(cursor)) || h.id.equals(bp.id(hot))) {
            e.setCancelled(true);
            return;
        }

        // keine Rucksaecke im Rucksack
        boolean clickedTop = e.getClickedInventory() != null && e.getClickedInventory().equals(top);
        boolean intoTop = clickedTop
                ? (bp.isBackpack(cursor) || bp.isBackpack(hot))
                : (e.isShiftClick() && bp.isBackpack(cur));
        if (intoTop) {
            e.setCancelled(true);
            p.sendMessage(Component.text("Rucksaecke passen nicht in Rucksaecke.", NamedTextColor.RED));
            return;
        }

        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && p.getOpenInventory().getTopInventory().equals(top)) save(p, h);
        });
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        BackpackHolder h = holderOf(top);
        if (h == null || !(e.getWhoClicked() instanceof Player p)) return;

        ItemStack dragged = e.getOldCursor();
        boolean touchesTop = false;
        for (int slot : e.getRawSlots()) {
            if (slot < top.getSize()) {
                touchesTop = true;
                break;
            }
        }
        if (touchesTop && bp.isBackpack(dragged)) {
            e.setCancelled(true);
            p.sendMessage(Component.text("Rucksaecke passen nicht in Rucksaecke.", NamedTextColor.RED));
            return;
        }
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && p.getOpenInventory().getTopInventory().equals(top)) save(p, h);
        });
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        BackpackHolder h = holderOf(e.getPlayer().getOpenInventory().getTopInventory());
        if (h != null && h.id.equals(bp.id(e.getItemDrop().getItemStack()))) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ Crafting / Upgrades

    @EventHandler
    public void onPrepare(PrepareItemCraftEvent e) {
        Recipe r = e.getRecipe();
        if (!(r instanceof ShapedRecipe sr)) return;
        if (!sr.getKey().getNamespace().equals(plugin.getName().toLowerCase())) return;
        String k = sr.getKey().getKey();
        if (!k.startsWith("upgrade_")) return;

        int tier;
        try {
            tier = Integer.parseInt(k.substring("upgrade_".length()));
        } catch (NumberFormatException ex) {
            return;
        }
        ItemStack[] matrix = e.getInventory().getMatrix();
        ItemStack center = matrix.length >= 9 ? matrix[4] : null;
        if (!bp.isBackpack(center) || bp.tier(center) != tier - 1) {
            e.getInventory().setResult(null);
            return;
        }
        int oldTier = bp.tier(center);
        ItemStack[] contents = bp.read(center, bp.slots(oldTier));
        e.getInventory().setResult(bp.create(tier, contents));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        e.getPlayer().discoverRecipes(recipeKeys);
    }
}
