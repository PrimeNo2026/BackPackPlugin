package de.backpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Hilfsklasse: erkennt Rucksaecke und liest/schreibt deren Inhalt direkt im Item (PersistentDataContainer). */
public final class Backpacks {

    public static final int MAX_TIER = 5;
    public static final String[] NAMES = {"Leder", "Kupfer", "Eisen", "Gold", "Diamant"};
    private static final NamedTextColor[] COLORS = {
            NamedTextColor.GOLD, NamedTextColor.RED, NamedTextColor.GRAY, NamedTextColor.YELLOW, NamedTextColor.AQUA};
    private static final int[] RGB = {0xA0653F, 0xC46A3C, 0xCFCFCF, 0xF5C842, 0x3FD8D8};

    private final JavaPlugin plugin;
    private final NamespacedKey keyTier;
    private final NamespacedKey keyId;
    private final NamespacedKey keyItems;
    private final NamespacedKey keySlots;

    public Backpacks(JavaPlugin plugin) {
        this.plugin = plugin;
        this.keyTier = new NamespacedKey(plugin, "tier");
        this.keyId = new NamespacedKey(plugin, "id");
        this.keyItems = new NamespacedKey(plugin, "items");
        this.keySlots = new NamespacedKey(plugin, "slots");
    }

    public int slots(int tier) {
        int s = plugin.getConfig().getInt("slots." + tier, tier * 9);
        return Math.max(9, Math.min(54, (s / 9) * 9));
    }

    public boolean isBackpack(ItemStack it) {
        if (it == null || it.getType() != Material.LEATHER_HORSE_ARMOR) return false;
        ItemMeta m = it.getItemMeta();
        if (m == null) return false;
        return m.getPersistentDataContainer().has(keyTier, PersistentDataType.INTEGER);
    }

    private PersistentDataContainer pdc(ItemStack it) {
        return it.getItemMeta().getPersistentDataContainer();
    }

    public int tier(ItemStack it) {
        if (!isBackpack(it)) return 0;
        Integer t = pdc(it).get(keyTier, PersistentDataType.INTEGER);
        return t == null ? 0 : t;
    }

    public UUID id(ItemStack it) {
        if (!isBackpack(it)) return null;
        String s = pdc(it).get(keyId, PersistentDataType.STRING);
        if (s == null) return null;
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    /** Liest den Inhalt als Array mit genau {@code slots} Eintraegen (leere Slots = null). */
    public ItemStack[] read(ItemStack it, int slots) {
        ItemStack[] out = new ItemStack[slots];
        if (!isBackpack(it)) return out;
        PersistentDataContainer c = pdc(it);
        byte[] bytes = c.get(keyItems, PersistentDataType.BYTE_ARRAY);
        int[] idx = c.get(keySlots, PersistentDataType.INTEGER_ARRAY);
        if (bytes == null || idx == null || bytes.length == 0) return out;
        ItemStack[] items = ItemStack.deserializeItemsFromBytes(bytes);
        for (int i = 0; i < items.length && i < idx.length; i++) {
            int s = idx[i];
            if (s >= 0 && s < slots && items[i] != null && !items[i].getType().isAir()) out[s] = items[i];
        }
        return out;
    }

    /** Schreibt Stufe, Inhalt, Name und Lore in das Item. Ist id null, bleibt eine vorhandene id erhalten. */
    public void write(ItemStack item, int tier, UUID id, ItemStack[] contents) {
        final int slots = slots(tier);
        List<ItemStack> list = new ArrayList<>();
        List<Integer> idx = new ArrayList<>();
        if (contents != null) {
            for (int i = 0; i < contents.length && i < slots; i++) {
                ItemStack s = contents[i];
                if (s != null && !s.getType().isAir()) {
                    list.add(s);
                    idx.add(i);
                }
            }
        }
        final byte[] bytes = list.isEmpty() ? new byte[0] : ItemStack.serializeItemsAsBytes(list);
        final int[] idxArr = idx.stream().mapToInt(Integer::intValue).toArray();
        final int used = list.size();
        final int ti = Math.max(1, Math.min(MAX_TIER, tier));
        final boolean customModels = plugin.getConfig().getBoolean("custom-models", true);

        item.editMeta(m -> {
            PersistentDataContainer c = m.getPersistentDataContainer();
            c.set(keyTier, PersistentDataType.INTEGER, tier);
            if (id != null) c.set(keyId, PersistentDataType.STRING, id.toString());
            c.set(keyItems, PersistentDataType.BYTE_ARRAY, bytes);
            c.set(keySlots, PersistentDataType.INTEGER_ARRAY, idxArr);

            m.displayName(Component.text("Rucksack (" + NAMES[ti - 1] + ")", COLORS[ti - 1])
                    .decoration(TextDecoration.ITALIC, false));
            List<Component> lore = new ArrayList<>();
            lore.add(Component.text("Stufe " + tier + "/" + MAX_TIER, NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Belegt: " + used + "/" + slots, NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Rechtsklick zum Oeffnen", NamedTextColor.DARK_GRAY)
                    .decoration(TextDecoration.ITALIC, false));
            m.lore(lore);
            if (m instanceof LeatherArmorMeta lm) lm.setColor(Color.fromRGB(RGB[ti - 1]));
            if (customModels) m.setItemModel(NamespacedKey.fromString("backpack:backpack_" + ti));
        });
    }

    public ItemStack create(int tier, ItemStack[] contents) {
        ItemStack it = new ItemStack(Material.LEATHER_HORSE_ARMOR);
        write(it, tier, null, contents);
        return it;
    }
}
